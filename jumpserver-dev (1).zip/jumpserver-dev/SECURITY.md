# 安全说明

JumpServer 是一款正在成长的安全产品， 请参考 [基本安全建议](https://docs.jumpserver.org/zh/master/install/install_security/) 部署安装.

如果你发现安全问题，请直接联系我们，我们携手让世界更好：

- ibuler@fit2cloud.com
- support@fit2cloud.com
- 400-052-0755


# Security Policy
JumpServer is a security product, The installation and development should follow our security tips.

## Reporting a Vulnerability
All security bugs should be reported to the contact as below:

- ibuler@fit2cloud.com
- support@fit2cloud.com
- 400-052-0755

