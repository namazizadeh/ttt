from django.dispatch import Signal

radius_create_user = Signal()
