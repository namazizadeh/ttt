# coding:utf-8

app_name = 'assets'

urlpatterns = [
]
